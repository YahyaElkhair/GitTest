package com.gestion.examen.planifier.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;


@Entity
public class SemestreModule {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id_semestreModule;


    @ManyToOne
    @JoinColumn(name = "id_semestre") // Nom de la colonne dans la table Semestre faisant référence à la clé primaire de la table Semestre
    private Semestre semestre;


    @ManyToOne
    @JoinColumn(name = "id_module") // Nom de la colonne dans la table Module faisant référence à la clé primaire de la table Module
    private Module module;
}
