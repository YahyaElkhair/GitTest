package com.gestion.examen.planifier.service.impl;


import com.gestion.examen.planifier.entities.Semestre;
import com.gestion.examen.planifier.entities.SemestreModule;
import com.gestion.examen.planifier.service.SemestreModuleService;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class SemestreModuleServiceImpl implements SemestreModuleService {

    public List<SemestreModule> getAllSemestreModule(){
        return null ;
    }
}
