package com.gestion.examen.planifier.service.impl;

import com.gestion.examen.planifier.service.ModuleService;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class ModuleServiceImpl implements ModuleService {

    public List<Module> getAllModule(){
        return null;
    }
}
