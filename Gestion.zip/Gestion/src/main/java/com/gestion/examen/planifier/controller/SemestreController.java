package com.gestion.examen.planifier.controller;

public class SemestreController {
}
