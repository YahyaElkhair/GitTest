package com.gestion.examen.planifier.entities;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Entity;

@Entity
public class ModuleEnseignant {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id_moduleEnseignant;


    private boolean estResponsable;


    @ManyToOne
    @JoinColumn(name = "id_module")
    private Module m_module;


    @ManyToOne
    @JoinColumn(name = "id_enseignant")
    private Enseignant m_enseignant;


    @ManyToOne
    @JoinColumn(name = "id_tirage")
    private Tirage m_Tirage;
}
