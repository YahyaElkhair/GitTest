package com.gestion.examen.planifier.entities;

import java.util.List;
import jakarta.persistence.Entity;
import jakarta.persistence.CascadeType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Module {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id_module;


    private String nom_module;


    @ManyToOne
    @JoinColumn(name = "id_filiere") // Nom de la colonne dans la table Module faisant référence à la clé primaire de la table Filiere
    private Filiere m_filiere;


    @OneToMany(mappedBy = "module", cascade = CascadeType.ALL)
    private List<ModuleEnseignant> modulesEnseignants;


    @OneToMany(mappedBy = "module", cascade = CascadeType.ALL)
    private List<SemestreModule> semestreModules;
}
