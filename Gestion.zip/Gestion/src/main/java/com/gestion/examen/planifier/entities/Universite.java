package com.gestion.examen.planifier.entities;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Universite {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String id_universite;


    private String nom_universite;
    private String president;
    private String adresse_universite;

    @OneToMany(mappedBy = "universite", cascade = CascadeType.ALL)
    private List<Local> locaux;

    @OneToMany(mappedBy = "universite", cascade = CascadeType.ALL)
    private List<Departement> departements;


    @OneToMany(mappedBy = "universite", cascade = CascadeType.ALL)
    private List<Personne> personnes;


    @ManyToOne
    @JoinColumn(name = "id_universite_") // Nom de la colonne dans la table FiliereUniversite faisant référence à la clé primaire de la table Universite
    private List<FiliereUniversite> m_filiereUniversite;
}
