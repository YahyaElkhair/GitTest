package com.gestion.examen.planifier.entities;

import jakarta.persistence.Entity;
import java.util.List;
import jakarta.persistence.CascadeType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;


@EqualsAndHashCode(callSuper = true)
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Enseignant extends Personne {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id_enseignant;


    @ManyToOne
    @JoinColumn(name = "id_departement") // Nom de la colonne dans la table Enseignant faisant référence à la clé primaire de la table Departement
    private Departement departement;


    @OneToMany(mappedBy = "enseignant", cascade = CascadeType.ALL)
    private List<ModuleEnseignant> moduleEnseignant ;
}
