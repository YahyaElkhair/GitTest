package com.gestion.examen.planifier.controller;
import com.gestion.examen.planifier.service.EnseignantService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class EnseignantController {
    /*@Autowired
    private EnseignantService enseignantService;


    @GetMapping("/Enseiganat")
    public String listEnseignant(Model model){
        model.addAttribute("etudiant", enseignantService.getAllEnseignat());
        return "etudiant/listEtudiant";
    }*/
        
    }



