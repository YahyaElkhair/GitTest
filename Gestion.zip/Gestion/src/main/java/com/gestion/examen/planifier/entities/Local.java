package com.gestion.examen.planifier.entities;

import jakarta.persistence.Entity;
import java.util.List;
import jakarta.persistence.CascadeType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Local {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id_local;


    private int capacite;
    protected boolean disponibilite;
    private String numero_local;
    private String type_local;


    @ManyToOne
    @JoinColumn(name = "id_universite") // Nom de la colonne dans la table Local faisant référence à la clé primaire de la table Universite
    private Universite m_Universite;


    @OneToMany(mappedBy = "local", cascade = CascadeType.ALL)
    private List<SeanceExamen> m_seance_Examen;
}
