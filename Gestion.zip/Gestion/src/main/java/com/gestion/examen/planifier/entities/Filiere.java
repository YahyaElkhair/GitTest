package com.gestion.examen.planifier.entities;

import java.util.List;
import jakarta.persistence.CascadeType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Filiere {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id_filiere;


    private String nom_filiere;


    @OneToMany(mappedBy = "m_filiere", cascade = CascadeType.ALL)
    private List<Semestre> semestres;


    @OneToMany(mappedBy = "m_filiere", cascade = CascadeType.ALL)
    private List<Module> modules;


    @OneToMany(mappedBy = "filiere", cascade = CascadeType.ALL)
    private List<FiliereUniversite> m_filiereUniversite;
}
