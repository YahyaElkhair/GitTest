package com.gestion.examen.planifier.entities;

import java.util.List;
import java.util.Date;
import jakarta.persistence.CascadeType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
public class SeanceExamen {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id_seance;


    private Date date_seance;
    private Heur heur_debut;
    private Heur heur_fin;
    private String type_examen;

    @ManyToOne
    @JoinColumn(name = "id_personne") // Nom de la colonne dans la table Seance_Examen faisant référence à la clé primaire de la table Personne
    private Personne m_Personne;


    @ManyToOne
    @JoinColumn(name = "id_tirage") // Nom de la colonne dans la table Seance_Examen faisant référence à la clé primaire de la table Tirage
    private Tirage m_Tirage;


    @ManyToOne
    @JoinColumn(name = "id_semestre") // Nom de la colonne dans la table Seance_Examen faisant référence à la clé primaire de la table Semestre
    private Semestre m_Semestre;


    @ManyToOne
    @JoinColumn(name = "id_module") // Nom de la colonne dans la table Seance_Examen faisant référence à la clé primaire de la table Module
    private Module m_Module;


    @ManyToMany
    @JoinTable(
            name = "seance_examen_local",
            joinColumns = @JoinColumn(name = "seance_id"),
            inverseJoinColumns = @JoinColumn(name = "id_local")
    )
    private List<Local> Locaux;


    @OneToMany(mappedBy = "personne", cascade = CascadeType.ALL)
    private List<Participation> m_participation;
}
