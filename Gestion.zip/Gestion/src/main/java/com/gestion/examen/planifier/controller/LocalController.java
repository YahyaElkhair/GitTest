package com.gestion.examen.planifier.controller;

public class LocalController {
}
