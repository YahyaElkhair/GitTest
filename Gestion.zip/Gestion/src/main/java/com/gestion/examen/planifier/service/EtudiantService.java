package com.gestion.examen.planifier.service;

import com.gestion.examen.planifier.respository.EtudiantRep;

import java.util.List;

public interface EtudiantService {
    List<EtudiantRep> getAllEtudiant();
}
