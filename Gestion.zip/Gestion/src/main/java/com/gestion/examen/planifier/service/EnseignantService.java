package com.gestion.examen.planifier.service;

import com.gestion.examen.planifier.entities.Enseignant;
import com.gestion.examen.planifier.respository.EnseignantRep;

import java.util.List;

public interface EnseignantService {

    //List<Enseignant> getAllEnseignat();


}
