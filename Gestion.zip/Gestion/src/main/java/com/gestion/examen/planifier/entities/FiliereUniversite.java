package com.gestion.examen.planifier.entities;

import java.util.Date;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;


@Entity

public class FiliereUniversite {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id_filiereUniversite;


    private Date anneeOuverture;

    @ManyToOne
    @JoinColumn(name = "id_filiere_") // Nom de la colonne dans la table FiliereUniversite faisant référence à la clé primaire de la table Filiere
    private Filiere m_filiere;

    @ManyToOne
    @JoinColumn(name = "universite_id") // Nom de la colonne dans la table FiliereUniversite faisant référence à la clé primaire de la table Universite
    private Universite m_universite;

}
