package com.gestion.examen.planifier.controller;

import org.springframework.stereotype.Controller;

@Controller
public class DepartementController {

}
