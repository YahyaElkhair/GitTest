package com.gestion.examen.planifier.entities;

import java.util.Date;
import jakarta.persistence.Entity;
import java.util.List;
import jakarta.persistence.CascadeType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
public  class Personne {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String id_personne;


    protected String adresse;
    protected String cni;
    protected Date date_naissance;
    protected String email;
    protected String nom;
    protected String prenom;
    protected String telephone;

    @ManyToOne
    @JoinColumn(name = "id_universite") // Nom de la colonne dans la table Personne faisant référence à la clé primaire de la table Universite
    private Universite m_Universite;


    @OneToMany(mappedBy = "personne", cascade = CascadeType.ALL)
    private List<Participation> m_participation ;

}
