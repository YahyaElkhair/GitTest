package com.gestion.examen.planifier.service.impl;

import com.gestion.examen.planifier.entities.Departement;
import com.gestion.examen.planifier.service.DepartementService;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class DepartementServiceImpl implements DepartementService {
    @Override
    public List<Departement> getAllDepartement(){
        return null;
    }
}
