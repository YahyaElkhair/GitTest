package com.gestion.examen.planifier.service.impl;

import com.gestion.examen.planifier.entities.Enseignant;
import com.gestion.examen.planifier.entities.FiliereUniversite;
import com.gestion.examen.planifier.service.FiliereUniversiteService;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class FiliereUniversiteServiceImpl implements FiliereUniversiteService{



    public List<FiliereUniversite> getAllFiliereUniversite(){
        return null ;
    }
}
