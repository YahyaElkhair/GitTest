package com.gestion.examen.planifier.service;public interface LocalService {
}
