package com.gestion.examen.planifier.entities;

import jakarta.persistence.Entity;
import java.util.List;
import jakarta.persistence.CascadeType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Semestre {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id_semestre;


    private String annee;
    private int numero_semestre;


    @ManyToOne
    @JoinColumn(name = "id_filiere") // Nom de la colonne dans la table Semestre faisant référence à la clé primaire de la table Filiere
    private Filiere m_Filiere;


    @OneToMany(mappedBy = "semestre", cascade = CascadeType.ALL)
    private List<SemestreModule> semestreModules;


    @OneToMany(mappedBy = "semestre", cascade = CascadeType.ALL)
    private List<SeanceExamen> m_seance_Examen;

}
