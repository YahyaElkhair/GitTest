package com.gestion.examen.planifier.service;

import com.gestion.examen.planifier.entities.Departement;

import java.util.List;

public interface DepartementService {
    List<Departement> getAllDepartement();
}
