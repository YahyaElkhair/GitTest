package com.gestion.examen.planifier.service.impl;

import com.gestion.examen.planifier.respository.EtudiantRep;
import com.gestion.examen.planifier.service.EtudiantService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EtudiantServiceImpl implements EtudiantService {
    private final EtudiantRep etudiantRep;

    public EtudiantServiceImpl(EtudiantRep etudiantRep) {
        this.etudiantRep = etudiantRep;
    }

    @Override
    public List<EtudiantRep> getAllEtudiant(){
        return etudiantRep.findAll();
    }
}
