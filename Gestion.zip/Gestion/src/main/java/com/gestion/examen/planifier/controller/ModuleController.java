package com.gestion.examen.planifier.controller;

public class ModuleController {
}
