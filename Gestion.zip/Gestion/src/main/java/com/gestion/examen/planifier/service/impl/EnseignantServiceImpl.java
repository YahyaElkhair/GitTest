package com.gestion.examen.planifier.service.impl;

import com.gestion.examen.planifier.entities.Enseignant;
import com.gestion.examen.planifier.respository.EnseignantRep;
import com.gestion.examen.planifier.service.EnseignantService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class EnseignantServiceImpl implements EnseignantService {
     /*@Autowired
    private final EnseignantRep enseignantRep;

    public EnseignantServiceImpl(EnseignantRep enseignantRep) {
        this.enseignantRep = enseignantRep;
    }

    public List<EnseignantRep> getAllEnseignant(){
        return enseignantRep.findAll();
    }
//?????????
    @Override
    public List<Enseignant> getAllEnseignat() {
        return List.of();
    }*/
}
