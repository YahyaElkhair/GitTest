package com.gestion.examen.planifier.service.impl;

import com.gestion.examen.planifier.entities.Enseignant;
import com.gestion.examen.planifier.entities.Semestre;
import com.gestion.examen.planifier.service.SemestreService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SemestreServiceImpl implements SemestreService {


    public List<Semestre> getAllSemestre(){
        return null ;
    }
}
