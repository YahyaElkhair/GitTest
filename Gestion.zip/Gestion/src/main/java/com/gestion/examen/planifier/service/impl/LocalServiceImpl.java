package com.gestion.examen.planifier.service.impl;

import com.gestion.examen.planifier.entities.Local;
import com.gestion.examen.planifier.service.LocalService;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class LocalServiceImpl implements LocalService {

    public List<Local> getAllLocal(){
        return null;
    }
}
