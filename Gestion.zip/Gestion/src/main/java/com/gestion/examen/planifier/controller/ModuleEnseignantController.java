package com.gestion.examen.planifier.controller;

public class ModuleEnseignantController {
}
