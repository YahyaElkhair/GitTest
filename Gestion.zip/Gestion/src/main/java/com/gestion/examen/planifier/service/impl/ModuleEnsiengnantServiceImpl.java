package com.gestion.examen.planifier.service.impl;

import com.gestion.examen.planifier.entities.ModuleEnseignant;
import com.gestion.examen.planifier.service.ModuleEseignantService;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class ModuleEnsiengnantServiceImpl implements ModuleEseignantService {

    public List<ModuleEnseignant> getAllModuleEnseignant(){
        return null;
    }
}
