package com.gestion.examen.planifier.service.impl;

import com.gestion.examen.planifier.entities.Enseignant;
import com.gestion.examen.planifier.entities.Universite;
import com.gestion.examen.planifier.service.UniversiteService;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class UniversiteServiceImpl implements UniversiteService {


    public List<Universite> getAllUniversite(){
        return null ;
    }
}
