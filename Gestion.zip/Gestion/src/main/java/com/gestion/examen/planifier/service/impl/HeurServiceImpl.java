package com.gestion.examen.planifier.service.impl;

import com.gestion.examen.planifier.entities.Heur;
import com.gestion.examen.planifier.service.HeurService;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class HeurServiceImpl implements HeurService {


    public List<Heur> getAllHeur(){
        return null ;
    }
}
