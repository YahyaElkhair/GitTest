package com.gestion.examen.planifier;

import com.gestion.examen.planifier.entities.Etudiant;
import com.gestion.examen.planifier.respository.EtudiantRep;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class})
public class GestionApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(GestionApplication.class, args);
	}

	@Autowired
	private EtudiantRep etudiantRep;
	@Override
	public void run(String... args) throws Exception{
		Etudiant  etu = new Etudiant(1,"meryem","Informatique");
	}
}
