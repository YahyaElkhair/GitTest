package com.gestion.examen.planifier.service.impl;

import com.gestion.examen.planifier.entities.Enseignant;
import com.gestion.examen.planifier.entities.Vacataire;
import com.gestion.examen.planifier.service.VacataireService;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class VacataireServiceImpl implements VacataireService {

    public List<Vacataire> getAllVacataire(){
        return null ;
    }
}
