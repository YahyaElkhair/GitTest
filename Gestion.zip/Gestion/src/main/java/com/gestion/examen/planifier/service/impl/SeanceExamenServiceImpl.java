package com.gestion.examen.planifier.service.impl;


import com.gestion.examen.planifier.entities.SeanceExamen;
import com.gestion.examen.planifier.service.SeanceExamenService;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class SeanceExamenServiceImpl implements SeanceExamenService {

    public List<SeanceExamen> getAllSeanceExamen(){
        return null ;
    }
}
