package com.gestion.examen.planifier.controller;

public class SemestreModuleController {
}
