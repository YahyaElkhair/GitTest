package com.gestion.examen.planifier.service.impl;


import com.gestion.examen.planifier.entities.Tirage;
import com.gestion.examen.planifier.service.TirageService;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class TirageServiceImpl implements TirageService {


    public List<Tirage> getAllTirage(){
        return null ;
    }
}
