package com.gestion.examen.planifier.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Participation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id_participation;

    @ManyToOne
    @JoinColumn(name = "id_personne") // Nom de la colonne dans la table Participation faisant référence à la clé primaire de la table Personne
    private Personne m_Personne;

    @ManyToOne
    @JoinColumn(name = "id_seance_examen") // Nom de la colonne dans la table Participation faisant référence à la clé primaire de la table Seance_Examen
    private SeanceExamen m_Seance_Examen;
}
