package com.gestion.examen.planifier.service.impl;

import com.gestion.examen.planifier.entities.Enseignant;
import com.gestion.examen.planifier.entities.Participation;
import com.gestion.examen.planifier.service.ParticipationService;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class ParticipationServiceImpl implements ParticipationService {


    public List<Participation> getAllParticipation(){
        return null ;
    }
}
