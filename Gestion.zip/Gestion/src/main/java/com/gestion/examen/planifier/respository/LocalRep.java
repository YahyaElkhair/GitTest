package com.gestion.examen.planifier.respository;

public interface LocalRep {
}
