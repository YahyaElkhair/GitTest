package com.gestion.examen.planifier.service.impl;


import com.gestion.examen.planifier.entities.Filiere;
import com.gestion.examen.planifier.service.FiliereService;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class FiliereServiceImpl implements FiliereService {


    public List<Filiere> getAllFiliere(){
        return null;
    }
}
