package com.gestion.examen.planifier.controller;

import com.gestion.examen.planifier.service.EtudiantService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

public class EtudiantController {

    private EtudiantService etudiantService;

    @GetMapping("/etudiant")
   public String listEtudiant(Model model){
       model.addAttribute("etudiant", etudiantService.getAllEtudiant());
       return "etudiant";
   }
}
